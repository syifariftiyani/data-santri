<?php 


class Data_santri extends CI_Controller{

public function __construct() {
parent::__construct () ;
$this->load->model('m_data_santri') ;
}

public function index()
{
$data['data_santri'] = $this->m_data_santri->tampil_data()-> result();
$this->load->view('templates/header');
$this->load->view('templates/sidebar');
		$this->load->view('data_santri', $data);
$this->load->view('templates/footer');

}

} 