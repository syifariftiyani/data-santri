<?php 

class Data_santri extends CI_Controller {

    public function index() {
        $data['data_santri'] = $this->m_data_santri->tampil_data()->result();
        $this->load->view('templates/header');
       
        $this->load->view('data_santri', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_aksi() {
        $nama = $this->input->post('nama');
        $nama_wali_santri = $this->input->post('nama_wali_santri');
        $nis = $this->input->post('nis');
        $alamat = $this->input->post('alamat');
        $data = array(
            'nama_santri' => $nama,
            'nama_wali_santri' => $nama_wali_santri,
            'nis' => $nis,
            'alamat' => $alamat,
        );
        $this->m_data_santri->input_data($data, 'data_santri');
        redirect('data_santri/index');
    }
    public function hapus($id) {
        $where = array('id' => $id);
        $this->m_data_santri->hapus_data($where, 'data_santri');
        redirect('data_santri/index');
    }
}
