<?php 

class cipaa extends CI_Model {
public function get_data()
{
}
}

 ?>