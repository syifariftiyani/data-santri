<?php  

class M_data_santri extends CI_Model{
public function tampil_data()
{
return $this->db->get('data_santri');
}

public function input_data($data,$table)
{
  $this->db->insert($table,$data);
 }

}
