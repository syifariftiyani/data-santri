<!DOCTYPE html>
<html lang="en">
		
				<div class="m-header">
					<a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
					<a href="#!" class="b-brand">
						<!-- ========   change your logo hear   ============ -->
					
										</a>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css"> <!-- Ganti kalau kamu punya CSS lain -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/fontawesome.min.css"> <!-- Jika pakai fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/feather.css"> <!-- Jika pakai Feather Icons -->
<body>
<!-- Header -->
<header class="navbar pcoded-header navbar-expand-lg navbar-light header-dark">
    <div class="m-header">
        <a class="mobile-menu" id="mobile-collapse" href="#!">
            <span></span>
        </a>
        <a href="#!" class="b-brand">
            <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo" class="logo">
            <img src="<?php echo base_url(); ?>assets/images/logo-icon.png" alt="Logo Icon" class="logo-thumb">
        </a>
        <a href="#!" class="mob-toggler">
            <i class="feather icon-more-vertical"></i>
        </a>
    </div>
</header>
<!-- End Header -->

