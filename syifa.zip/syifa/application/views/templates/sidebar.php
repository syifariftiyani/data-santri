<!DOCTYPE html>
<html lang="en">
<head>
    <!-- vendor css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<body>

<!-- [ navigation menu ] start -->
<nav class="pcoded-navbar">
    <div class="navbar-wrapper">
        <div class="navbar-content scroll-div">

            <!-- User Info -->
            <div class="main-menu-header">
                <img class="img-radius" src="<?php echo base_url(); ?>assets/images/user/avatar-2.jpg" alt="User-Profile-Image">
                <div class="user-details">
                    <span>Syifa Riftiyani</span>
                    <div id="more-details">Admin<i class="fa fa-chevron-down m-l-5"></i></div>
                </div>
            </div>

            <!-- User Collapse Menu -->
            <div class="collapse" id="nav-user-link">
                <ul class="list-unstyled">
                    <li class="list-group-item"><a href="user-profile.html"><i class="feather icon-user m-r-5"></i>View Profile</a></li>
                    <li class="list-group-item"><a href="auth-normal-sign-in.html"><i class="feather icon-log-out m-r-5"></i>Logout</a></li>
                </ul>
            </div>

            <!-- Navigation Menu -->
            <ul class="nav pcoded-inner-navbar">
                <li class="nav-item pcoded-menu-caption">
                    <label>Navigation</label>
                </li>

                <!-- Menu Dashboard -->
                <li class="nav-item">
                    <a href="<?php echo site_url('admin'); ?>" class="nav-link">
                        <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                        <span class="pcoded-mtext">Dashboard</span>
                    </a>
                </li>

               <!-- Data Santri -->
<li class="nav-item">
    <a href="<?php echo site_url('data_santri'); ?>" class="nav-link">
        <span class="pcoded-micon"><i class="feather icon-users"></i></span>
        <span class="pcoded-mtext">Data Santri</span>
    </a>
</li>

                <!-- Kategori Pelanggaran -->
                <li class="nav-item">
                    <a href="tbl_bootstrap.html" class="nav-link">
                        <span class="pcoded-micon"><i class="feather icon-list"></i></span>
                        <span class="pcoded-mtext">Kategori Pelanggaran</span>
                    </a>
                </li>

                <!-- Pelanggaran Santri -->
                <li class="nav-item">
                    <a href="chart-apex.html" class="nav-link">
                        <span class="pcoded-micon"><i class="feather icon-alert-circle"></i></span>
                        <span class="pcoded-mtext">Pelanggaran Santri</span>
                    </a>
                </li>

                <!-- Laporan Pelanggaran -->
                <li class="nav-item">
                    <a href="map-google.html" class="nav-link">
                        <span class="pcoded-micon"><i class="feather icon-file-text"></i></span>
                        <span class="pcoded-mtext">Laporan Pelanggaran</span>
                    </a>
                </li>
            </ul>

        </div>
    </div>
</nav>
<!-- [ navigation menu ] end -->

</body>
</html>
