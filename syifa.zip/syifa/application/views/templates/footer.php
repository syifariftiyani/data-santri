<!-- JS Scripts -->
<script src="<?php echo base_url(); ?>assets/js/vendor-all.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/pcoded.min.js"></script>

<!-- Optional Plugins -->
<script src="<?php echo base_url(); ?>assets/js/plugins/apexcharts.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/pages/dashboard-main.js"></script>

</body>
</html>



