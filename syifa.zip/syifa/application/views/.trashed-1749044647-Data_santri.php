<div class="content-wrapper">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Pesantren Putri</h5>
                    </div>

                    <ul class="breadcrumb">
                        <li><a href="index.html"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Data santri</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <section class="content">
        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Tambah Data Santri</button>

        <table class="table">
            <thead>
                <tr>
                    <th>NO</th>
                    <th>NAMA SANTRI</th>
                    <th>NAMA WALI SANTRI</th>
                    <th>NIS</th>
                    <th>ALAMAT</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data_santri as $santri) : ?>
                    <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $santri->nama_santri; ?></td>
                        <td><?php echo $santri->nama_wali_santri; ?></td>
                        <td><?php echo $santri->nis; ?></td>
                        <td><?php echo $santri->alamat; ?></td>
                    </tr>
               <?php endforeach; ?>
            </tbody>
        </table>
    </section>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fs-5" id="exampleModalLabel">FORM INPUT DATA SANTRI</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
     
            </div>
        </div>
    </div>
</div>