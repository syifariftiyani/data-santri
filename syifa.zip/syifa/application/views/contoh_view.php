<!DOCTYPEhtml>
<html>
<head>
<title>Contoh View</title>
</head>
<body>

<h1>Cape Boleh Nyerah Jangan</h1>
<hr>
<p>diawali dengan bismillah di akhiri dengan alhamdulillah</p>
</body>
</html>