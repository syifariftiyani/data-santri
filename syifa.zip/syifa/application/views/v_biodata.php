<!DOCTYPE html>
<html>
<head>
<title>Biodata</title>
</head>
<body>
<table border="1px solid black">
   <tr>
     <th>NAMA</th>
     <th>TANGGAL LAHIR</th>
     <th>ALAMAT</th>
     <th>HOBI</th>
     <th>JENIS KELAMIN</th>

   </tr>
<?php foreach ($biodata as $biodata): ?>
<tr> 
<td><?php echo $biodata['nama']; ?></td>
<td><?php echo $biodata['tgl_lahir']; ?></td>
<td><?php echo $biodata['alamat']; ?></td>
<td><?php echo $biodata['hobi']; ?></td>
<td><?php echo $biodata['jenis_kelamin']; ?></td>


<?php endforeach; ?>
</tr>
</table>
</body>