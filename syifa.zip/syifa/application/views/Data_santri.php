<div class="content-wrapper">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Pesantren Putri</h5>
                    </div>

                    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Phoenixcoded" />
    <!-- Favicon icon -->
    <link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon.ico" type="image/x-icon">
   <body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>			
				<ul class="nav pcoded-inner-navbar ">
					<a href="#!" class="mob-toggler">
						<i class="feather icon-more-vertical"></i>
					</a>
				</div>
				<div class="collapse navbar-collapse">
					<ul class="navbar-nav mr-auto">
						<li class="nav-item">
							<a href="#!" class="pop-search"><i class="feather icon-search"></i></a>
							<div class="search-bar">
								<input type="text" class="form-control border-0 shadow-none" placeholder="Search hear">
								<button type="button" class="close" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
            <!-- <?php $this->load->view('templates/sidebar'); ?> -->
                    <ul class="breadcrumb">
                        <li><a href="index.html"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Data santri</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- [ breadcrumb ] end -->
    <section class="content">
        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i> Tambah Data Santri</button>
        <table class="table">
            <thead>
                <tr>
                    <th>NO</th>
                    <th>NAMA SANTRI</th>
                    <th>NAMA WALI SANTRI</th>
                    <th>NIS</th>
                    <th>ALAMAT</th>
                    <th colspan="2">AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data_santri as $santri) : ?>
                    <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $santri->nama_santri; ?></td>
                        <td><?php echo $santri->nama_wali_santri; ?></td>
                        <td><?php echo $santri->nis; ?></td>
                        <td><?php echo $santri->alamat; ?></td>
                        <td><?php echo anchor('data_santri/hapus/'.$santri->id, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?></td>
                        <td><div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div></td>
                    </tr>
               <?php endforeach; ?>
            </tbody>
        </table>
    </section>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fs-5" id="exampleModalLabel">FORM INPUT DATA SANTRI</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= site_url('data_santri/tambah_aksi') ?>">
                        <div class="form-group">
                            <label>Nama Santri</label>
                            <input type="text" name="nama" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Nama Wali Santri</label>
                            <input type="text" name="nama_wali_santri" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Nis</label>
                            <input type="text" name="nis" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                            <input type="text" name="alamat" class="form-control" required>
                        </div>
                        <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
